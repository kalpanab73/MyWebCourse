let x, y, z;

x=10;
y = '10';
z = 30;

console.log(`x is ${typeof x}`);

var newX = x++;

console.log(newX);

console.log('The comparison of x==y is: ', (x==y));

let timeInMs = Date.now();
console.log(timeInMs);

let newDate = new Date(timeInMs);




